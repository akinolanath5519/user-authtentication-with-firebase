# agripay

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


go to firebase flutter SDK to connect the project with the firebase

1.install node js
2.npm install -g firebase-tools
3.firebase login
4.dart pub global activate flutterfire_cli
5.flutterfire configure
6.flutter pub add firebase_core