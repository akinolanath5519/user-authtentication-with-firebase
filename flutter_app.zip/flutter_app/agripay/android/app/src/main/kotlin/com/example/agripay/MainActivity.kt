package com.example.agripay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
